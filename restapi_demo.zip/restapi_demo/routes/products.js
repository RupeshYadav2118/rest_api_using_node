var express = require('express');
var router = express.Router();
var db=require('../db');
var bodyParser = require('body-parser');

router.use(bodyParser.json());

//--------------------------reading products list-----------------------------------------                          

router.get('/', function(req, res, next) {
  var sql = "SELECT * from where active = 1";
  db.query(sql, function(err, rows, fields){
    if(err){
      res.status(500).send({error: 'failed'})
    }
    res.json(rows);
  })
  
});

//----------------------------- creating products list-------------------------------------

router.post('/create', function(req, res , next){
  var name = req.body.name;
  var sku = req.body.sku;
  var price = req.body.price;

  var sql = 'INSERT INTO products(name, sku, price, active, created_at VALUES ("$(name)", "$(sku)", "$(price), 1, NOW())';

  db.query(sql, function(err, result){
    if(err){
      res.status(500).send({error: 'failed'})
    }
    res.json({status: 'success', id: result.insertId})
  })
})

//--------------------------------------update product list--------------------------------

router.put('/update/:id', function(req, res , next){
  var id = req.params.id;
  var name = req.body.name;
  var sku = req.body.sku;
  var price = req.body.price;
var sql = 'UPDATE products SET name ="$(name)", sku="$(sku)", price="$(price)" WHERE id=$(id) ';

  db.query(sql, function(err, result){
    if(err){
      res.status(500).send({error: 'failed'})
    }
    res.json({status: 'success'})
  })
})



//----------------------------------delete product list--------------------------------------

router.delete('/delete/:id', function(req, res , next){
  var id = req.params.id;

var sql = 'DELETE FROM products WHERE id = $(id)';

  db.query(sql, function(err, result){
    if(err){
      res.status(500).send({error: 'failed'})
    }
    res.json({status: 'success'})
  })
})

module.exports = router;
